package Lab_Session_25;

public class prob1 {
	 private void myPrivateMethod() {
	        System.out.println("Invoking private method");
	    }
   
}
