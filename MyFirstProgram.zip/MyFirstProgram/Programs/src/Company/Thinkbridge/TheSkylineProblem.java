package Company.Thinkbridge;

public class TheSkylineProblem {
	public static void main(String[] args) {
		
	}
}
