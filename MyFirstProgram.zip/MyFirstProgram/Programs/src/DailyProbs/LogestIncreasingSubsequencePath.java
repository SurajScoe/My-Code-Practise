package DailyProbs;

import java.util.List;

public class LogestIncreasingSubsequencePath {
	public static void main(String[] args) {
		 int[] nums = {10, 22, 9, 33, 21, 50, 41, 60, 80};
	        List<Integer> lis = findLIS(nums);

	        System.out.println("Longest Increasing Subsequence: " + lis);
	}

	private static List<Integer> findLIS(int[] nums) {
		// TODO Auto-generated method stub
		return null;
	}
}
