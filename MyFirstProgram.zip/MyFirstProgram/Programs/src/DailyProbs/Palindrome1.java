package DailyProbs;

public class Palindrome1 {
	public static void main(String[] args) {
//		String str = "aba";
//		StringBuilder s = new StringBuilder(str);
//		
//		s.reverse();
//		System.out.println(str.equals(s.toString()));
		
		
//		String str1 = "abcdecccccc";
//		System.out.println(str1.replace(Character.toString('c'),""));
		
		
		
	}
}
