package DailyProbs;

import java.util.HashMap;

public class CompressAString {
	public static void main(String[] args) {
		String str = "abcd";
//		 StringBuilder compressed = new StringBuilder();
//	        char currentChar = str.charAt(0);
//	        int count = 1;
//
//	        for (int i = 1; i < str.length(); i++) {
//	            if (str.charAt(i) == currentChar) {
//	                count++;
//	            } else {
//	                compressed.append(currentChar);
//	                compressed.append(count);
//	                currentChar = str.charAt(i);
//	                count = 1;
//	            }
//	        }
//
//	        // Append the last character and its count
//	        compressed.append(currentChar);
//	        compressed.append(count);
////	        
////	        
////	        
//	        System.out.println(compressed.toString());
		
//		String s = "";
//		
//	        HashMap<Character,Integer> map = new HashMap<>();
//	        
//	        for(char ch : str.toCharArray()) {
//	        	map.put(ch,map.getOrDefault(ch,0)+1);
//	        }
//	        
//	        for(char key : map.keySet()) {
//	        	int occ = map.get(key);
//	        	s += key +""+ occ;
//	        }
//	        
//	        System.out.println(s);
		
		
		
		
//		String str = "aaabbbcc";
//		int i = 0;
//		int j = 0;
//		
//		char [] c=str.toCharArray();
//		Map<Char, V>
		
		
		
		String s = null;
		System.out.println(s);
//		System.out.println(s.toLowerCase());
		s = s.toLowerCase();
		s = "";
		System.out.println(s);
	}
}
