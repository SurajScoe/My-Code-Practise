package innerClass.type2MethodLocalInnerClasses;

public class Main {
	public static void main(String[] args) {
		Outer o = new Outer();
		o.outerMethod();
	}
}
