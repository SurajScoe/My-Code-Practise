package LambdaExpression;

public class MyInterImpl implements MyInterface {

	@Override
	public void MyHello() {
		// TODO Auto-generated method stub
		System.out.println("Inside the implemented class");
	}

}
