package LambdaExpression;

public interface MyInterface {
	public void MyHello();
}
