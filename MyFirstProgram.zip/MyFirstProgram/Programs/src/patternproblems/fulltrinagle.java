package patternproblems;

public class fulltrinagle {
	public static void main(String[] args) {
		
	}
}
