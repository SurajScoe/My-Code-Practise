package ThreadPart1AndPart2;

/*==>It is highly recommended to ovrride run() otherwise don't go for multithreading 
 * conscepts
 * */

public class MyProg2 {
	public static void main(String[] args) {
		
	}
}
