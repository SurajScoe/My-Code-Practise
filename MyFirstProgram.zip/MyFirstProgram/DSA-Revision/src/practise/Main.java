package practise;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentLL l = new StudentLL();
		l.insert(new Student(101, "suraj"));
		l.display();
	}

}
